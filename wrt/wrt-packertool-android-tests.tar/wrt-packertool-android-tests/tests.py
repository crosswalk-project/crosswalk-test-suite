#!/usr/bin/env python 
# coding=utf-8 
import random,os,sys,unittest,run_app,codecs 
reload(sys) 
sys.setdefaultencoding( "utf-8" ) 
class TestCaseUnit(unittest.TestCase): 
 
  def test_positive_cmd1(self):
     self.assertEqual("PASS", run_app.tryRunApp("cmd1-positive", "/opt/wrt-packtertool-android-tests/apks/x86/cmd1-positive"))

  def test_positive_cmd205(self):
     self.assertEqual("PASS", run_app.tryRunApp("cmd205-positive", "/opt/wrt-packtertool-android-tests/apks/x86/cmd205-positive"))

  def test_positive_cmd206(self):
     self.assertEqual("PASS", run_app.tryRunApp("cmd206-positive", "/opt/wrt-packtertool-android-tests/apks/x86/cmd206-positive"))

  def test_negative_cmd262(self):
     self.assertEqual("PASS", run_app.tryRunApp("cmd262-negative", "/opt/wrt-packtertool-android-tests/apks/x86/cmd262-negative"))

  def test_positive_cmd33(self):
     self.assertEqual("PASS", run_app.tryRunApp("cmd33-positive", "/opt/wrt-packtertool-android-tests/apks/x86/cmd33-positive"))

if __name__ == '__main__':
    unittest.main()
